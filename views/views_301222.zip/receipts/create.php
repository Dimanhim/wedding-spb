<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Receipt */

$this->title = 'Добавление чека';
$this->params['breadcrumbs'][] = ['label' => 'Чеки', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
